# Dino's Pizza & Pasta — Local Package Manifest

- Created: 2026-05-05
- Updated: 2026-05-05 01:51 America/Chicago
- Archive: `restaurant-website-system/sites/dino-s-pizza-pasta/delivery-artifacts/dino-s-pizza-pasta-local-package-2026-05-05.tar.gz`
- SHA-256: `8d06c99578f5b11e4ef929bf0bfc55380620aff98d1df6b7559d7c51bb53f447`
- Size: 4.6 MB

## Contents

The archive includes:

- Next.js source: `app/`, `components/`, `lib/`, `content.ts`, `theme.ts`, config files, and package files.
- Source/evidence docs: `source.md`, `audit.md`, `build-evidence-2026-05-05.md`, improvement/top-3 docs, concierge KB/transcript, pitch doc, battle cards, QA round docs, delivery package draft, owner confirmation packet, public preview runbook, and checklist files.
- Evidence assets: `screenshots/`, `scrapes/`, and QA CDP scripts.

The archive excludes `node_modules`, `.next`, `.git`, and prior package archives.

## Status

This is a local handoff/deployment package only. It is not a public preview URL and does not satisfy final delivery until Mission Control writeback, owner confirmation, and owner-shareable preview are available.
